import processing.sound.*;
SoundFile clickSound;
SoundFile backgroundSound;
int score;
int text;
int textIndex = 0;
int state;
boolean oneClick;
boolean choices;
boolean showOfficer = false;
PImage bedroom;
PImage classroom;
PImage lunch;
PImage gym;
PImage jail;
PImage sticker;
PImage jessica0;
PImage coach;
PImage tori;

PImage[] officer;
int officerCurrent = 0;
int officerDelay = 10;

PImage[] teacher;
int teacherCurrent = 0;
int teacherDelay = 10;

PImage[] jessicaMad;
int jessicaCurrent = 0;
int jessicaDelay = 20;


TextBox[] box1;
TextBox[] box1BringApple;
TextBox[] box1Skip;
TextBox[] box1GoToSchool;

TextBox[] box2;
TextBox[] box2Sleep;
TextBox[] box2TakeNotes;
TextBox[] box2RaiseYourHand;

TextBox[] box3;
TextBox[] box3Ketchup;
TextBox[] box3Water;
TextBox[] box3Milk;

TextBox[] box4;
TextBox[] box4NoChoice;

TextBox[] box5Jail;
TextBox[] box5Detention;
TextBox[] box5Party;
TextBox[] box5StarStudent;


Button button1;
Button button2;
Button option1;
Button option2;
Button option3;

void setup() {
  size(800, 600);
  background(150);
  //initializing sound
  clickSound = new SoundFile(this, "click.wav");
  // nextSound = new SoundFile(this, "next.wav");
  backgroundSound = new SoundFile(this, "background.wav");
  backgroundSound.loop();
  backgroundSound.amp(0.1);
  score = 0;
  bedroom = loadImage("Bedroom0.png");
  classroom = loadImage("classroom0.png");
  lunch = loadImage("lunch0.png");
  gym = loadImage("gym0.png");
  jail = loadImage("jail0.png");
  coach = loadImage("coach0.png");
  officer = new PImage[2];
  officer[0] = loadImage("officer1.png");
  officer[1] = loadImage("officer2.png");
  
  teacher = new PImage[2];
  teacher[0] = loadImage("teacher0.png");
  teacher[1] = loadImage("teacher1.png");
  
  jessica0 = loadImage("Jessica0.png");
  tori = loadImage("Tori0.png");
  sticker = loadImage("sticker0.png");
  
  jessicaMad = new PImage[2];
  jessicaMad[0] = loadImage("Jessica1.png");
  jessicaMad[1] = loadImage("Jessica2.png");

  
  bedroom.resize(800, 600);
  classroom.resize(800, 600);
  lunch.resize(800, 600);
  gym.resize(800, 600);
  teacher[0].resize(200, 300);
  teacher[1].resize(200, 300);
  jessica0.resize(200,200);
  coach.resize(300,300);
  tori.resize(300,300);
  sticker.resize(200,200);
  jessicaMad[0].resize(200, 200);
  jessicaMad[1].resize(200, 200);
  //BEDROOM
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  box1 = new TextBox[] {
    new TextBox(width/2, 6 * height/7, 600, 50, "You wake up to the sun shining on your face.", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "It’s your first day at a new school.", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "What will you do?", 18),
  };
  box1BringApple = new TextBox[]{
      new TextBox(width/2, 6 * height/7, 600, 50, "Next scene.", 18),
  };
  box1Skip = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Officer: Hey kid you should be in school!", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Officer: Don’t do this again or you’ll be in huge trouble.", 18),
  };
  box1GoToSchool = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Next Scene.", 18)
  };
  //CLASSROOM
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  box2 = new TextBox[] {
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Good morning class!", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Today we will be learning about the Revolutionary War", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Does anyone know anything about it?", 18)
  };
  box2Sleep = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Wake up! This is NOT naptime!", 18),
  };
  box2TakeNotes = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: On April 19th, 1775 the...", 18),
  };
  box2RaiseYourHand = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Next Scene.", 18)
  };
  //LUNCH
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  box3 = new TextBox[] {
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: Hey new kid! Sit here.", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: I was just about to spill the tea about Tori", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: She got this boyfriend over the summer..", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: But ever since she has avoided us!", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "What will you drink while Jessica is talking?", 18),
  };
  box3Ketchup = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: EWW DID YOU JUST DRINK KETCHUP!?", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: I think it would be best if you sat somewhere else.", 18),
  };
  box3Water = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: Anyway she said she’s more mature now", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: And doesn't want to hang out anymore", 18),
  };
  box3Milk = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: Oo good choice.", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: Anyway she said she’s more mature now", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: And doesn't want to hang out anymore", 18),
  };
  //GYM
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  box4 = new TextBox[] {
    new TextBox(width/2, 6 * height/7, 600, 50, "Gym Teacher: Alright class it’s the first day", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Gym Teacher: So I figured lets just play a game", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Gym Teacher: I prefer to start out easy", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "What will you vote for?", 18)
  };
  box4NoChoice = new TextBox[] {
    new TextBox(width/2, 6 * height/7, 600, 50, "Next Scene.", 18)
  };
  //ENDINGS
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  box5Jail = new TextBox[] {
    new TextBox(width/2, 6 * height/7, 600, 50, "Officer: I told you you'd be in trouble if you did it again.", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Officer: You know it’s a crime to skip school.", 18)
  };
  box5StarStudent = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: You did very well today", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Keep this up and you’ll be student of the week!", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Here's a sticker for your good work!", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "You overhear a conversation.", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Tori: They’re a kiss up. No way I’m inviting them to my party!", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Jessica: No kidding! I had lunch with them…they were kind of boring", 18)
  };
  box5Party = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Tori: Hey you seem pretty cool", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Tori: I’m having a back to school party at my house", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Tori: You should totally come", 18)
  };
  box5Detention = new TextBox[]{
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Hey, can you stay after class?", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: You made some poor decisions today", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: You’re getting detention all this week.", 18),
    new TextBox(width/2, 6 * height/7, 600, 50, "Teacher: Try to make better decisions next time", 18)
  };


  button1 = new Button(width/2, 2 * height/3, 150, 50, #FF0000);
  button2 = new Button(width - 30, 6 * height/7, 40, 40, color(150));
  
  option1 = new Button(width/4, height/2, 200, 50, color(#D33136));
  option2 = new Button(width/2, height/2, 200, 50, color(#BDD331));
  option3 = new Button(3 * width/4, height/2, 200, 50, color(#3140D3));
}
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
void draw() {

  switch (state) {
  case 0:
    break;

  case 1:
    break;

  case 2:
    break;

  case 3:
    break;

  case 4:
    break;

  case 5:
    break;
    
    case 6:
    break;
  }
  if (state == 0) {
    startScreen();
  }

  if (state == 1) {
    bedroom();
  }
  if (state == 2) {
    classroom();
  }
  if (state == 3) {
    lunch();
  }
  if (state == 4) {
    gym();
  }
  // this will need adjusting because many different endings
  if (state == 5) {
    ending();
  }
  if (state == 6){
    endScreen();
  }

  if (button2.isPressed()) {
    // i know nextSound and clickSound overlap I just like it
    //  nextSound.play();
  }
  if (!backgroundSound.isPlaying()) {

    backgroundSound.loop();
  }
 
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void mousePressed() {
  clickSound.stop();
  clickSound.play();

  if (choices) {

// BEDROOM CHOICES
    if (state == 1) {
      if (option1.isInButton()) {
        choices = false;
        textIndex = 0;
        box1 = box1BringApple;
        score += 1;
      }
      if (option2.isInButton()) {
        choices = false;
        showOfficer = true;
        textIndex = 0;
        box1 = box1Skip;
        score -= 1;
      }
      if (option3.isInButton()) {
        choices = false;
        textIndex = 0;
        box1 = box1GoToSchool;
      }
    }

// CLASSROOM
    if (state == 2) {
      if (option1.isInButton()) {
        choices = false;
        textIndex = 0;
        box2 = box2Sleep;
        score -= 1;
      }
      if (option2.isInButton()) {
        choices = false;
        textIndex = 0;
        box2 = box2TakeNotes;
      }
      if (option3.isInButton()) {
        choices = false;
        textIndex = 0;
        box2 = box2RaiseYourHand;
        score += 1;
      }
    }
  }
// LUNCH CHOICES
  if (state == 3) {
   if (option1.isInButton()) {
    choices = false;
    textIndex = 0;
    box3 = box3Ketchup;
    score -= 1;
  }
   if (option2.isInButton()) {
    choices = false;
    textIndex = 0;
    box3 = box3Water;
    score += 1;
  }
   if (option3.isInButton()) {
    choices = false;
    textIndex = 0;
    box3 = box3Milk;
  }
}
// GYM CHOICES
  if (state == 4) {
   if (option1.isInButton()) {
    choices = false;
    textIndex = 0;
    box4 = box4NoChoice;
  }
   if (option2.isInButton()) {
    choices = false;
    textIndex = 0;
    score += 1;
    box4 = box4NoChoice;
  }
   if (option3.isInButton()) {
    choices = false;
    textIndex = 0;
    score -= 1;
    box4 = box4NoChoice;
  }
}
}
void mouseReleased() {
  oneClick = true;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void startScreen() {
  background(255);
  fill(0, 255, 0);
  textSize(75);
  textAlign(CENTER, CENTER);
  text("FIRST DAY OF SCHOOL", width/2, height/3);
  button1.render();
  textSize(45);
  fill(#120505);
  text("START", width/2, 2 * height/3 );
  if (button1.isPressed()) {
    state = state + 1;
    oneClick = false;
  }
}


//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
void bedroom() {
  imageMode(CENTER);
  image(bedroom, width/2, height/2);
  if (showOfficer) {
  drawOfficer(width/2, height/2 + 120);
}
  if (!choices) {
    drawButton();
    box1[textIndex].render();
    if (button2.isPressed() && oneClick) {
      textIndex += 1;
      oneClick = false;
    }
    if (textIndex == 3) {
      choices = true;
    }
    if (!choices && textIndex >= box1.length) {
      state += 1;
      textIndex = 0;
      oneClick = false;
    }
  }
 //// CHOICES SCREEN \\\\\
  else {
    option1.render();
    option2.render();
    option3.render();
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(16);
    text("Bring Apple", option1.x, option1.y);
    text("Skip School", option2.x, option2.y);
    text("Go Normally", option3.x, option3.y);
  }
}
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
void classroom() {
  background(0);
  image(classroom, width/2, height/2);
  drawTeacher(3 * width/4, height/2);
  if (!choices) {
    drawButton();
    box2[textIndex].render();
    if (button2.isPressed() && oneClick) {
      textIndex += 1;
      oneClick = false;
    }
    if (textIndex == 3) {
      choices = true;
    }
    if (!choices && textIndex >= box2.length) {
      state += 1;
      textIndex = 0;
      oneClick = false;
    }
  }
  //// CHOICES SCREEN \\\\
  else {
    option1.render();
    option2.render();
    option3.render();
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(16);
    text("Sleep", option1.x, option1.y);
    text("Take Notes", option2.x, option2.y);
    text("Raise Hand", option3.x, option3.y);
  }
}
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
void lunch() {
  background(0);
  image(lunch, width/2, height/2);
  if (box3 == box3Ketchup) {
  drawJessica(width/2, height/2 + 50); 
  } 
  else {
    image(jessica0, width/2, height/2 + 50); // normal Jessica
  }

  if (!choices) {
    drawButton();
    box3[textIndex].render();
    if (button2.isPressed() && oneClick) {
      textIndex += 1;
      oneClick = false;
    }
    if (textIndex == 5) {
      choices = true;
    }
    if (!choices && textIndex >= box3.length) {
      state += 1;
      textIndex = 0;
      oneClick = false;
    }
  }
  //// CHOICES SCREEN \\\\
  else {
    option1.render();
    option2.render();
    option3.render();

    fill(0);
    textAlign(CENTER, CENTER);
    textSize(16);

    text("Ketchup", option1.x, option1.y);
    text("Water", option2.x, option2.y);
    text("Milk", option3.x, option3.y);
  }
}
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
void gym() {
  background(0);
  image(gym, width/2, height/2);
  image(coach, 2 * width/3, height/2 + 50);

  if (!choices) {
    drawButton();
    box4[textIndex].render();
    if (button2.isPressed() && oneClick) {
      textIndex += 1;
      oneClick = false;
    }
    if (textIndex == 3) {
      choices = true;
    }
    if (!choices && textIndex >= box4.length) {
      state += 1;
      textIndex = 0;
      oneClick = false;
    }
  }
  //// CHOICES SCREEN \\\\
  else {
    option1.render();
    option2.render();
    option3.render();
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(16);
    text("Dodgeball", option1.x, option1.y);
    text("Basketball", option2.x, option2.y);
    text("Sit Out", option3.x, option3.y);
  }
}
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
void ending() {
  background(#FFAA00);
  drawButton();

  if (score == -4) {
    image(jail, width/2, height/2);
    drawOfficer(width/2, height/2 + 50);
    drawButton();
    box5Jail[textIndex].render();
    if (button2.isPressed()&& oneClick) {
      textIndex += 1;
      oneClick = false;
    }
    if (textIndex >= box5Jail.length) {
      state = 6;
      textIndex = 0;
      oneClick = false;
    }
  }
//////////////////////////////////////////////////////////////////////////
 if (score >= -3 && score <= -1) { 
   image(gym, width/2, height/2); 
   drawButton(); 
    drawTeacher(2 * width/3, height/2); 
    box5Detention[textIndex].render(); 
  if (button2.isPressed()&& oneClick) {
     textIndex += 1; oneClick = false; 
    }
    if (textIndex >= box5Detention.length) {
      state = 6;
      textIndex = 0;
      score = 0;
      oneClick = false;
    }
  }
//////////////////////////////////////////////////////////////////////////
  if (score >= 0 && score <= 3) {
    image(gym, width/2, height/2);
    drawButton();
   image(tori, width/2, height/2);
    box5Party[textIndex].render();
    if (button2.isPressed()&& oneClick) {
      textIndex += 1;
      oneClick = false;
    }
    if (textIndex >= box5Party.length) {
      state = 6;
      textIndex = 0;
      score = 0;
      oneClick = false;
    }
  }
//////////////////////////////////////////////////////////////////////////
  if (score == 4) {
    image(classroom, width/2, height/2);
    drawTeacher(2 * width/3, height/2);
    image(sticker, width/2, height/2);
    drawButton();
    box5StarStudent[textIndex].render();
    if (button2.isPressed()&& oneClick) {
      textIndex += 1;
      oneClick = false;
    }
    if (textIndex >= 2) {
      image(sticker, width/2, height/2);
    }
    if (textIndex >= box5StarStudent.length) {
      state = 6;
      textIndex = 0;
      score = 0;
      oneClick = false;
    }
  }
}
void endScreen(){
background(0);
  fill(255);
  textSize(75);
  textAlign(CENTER, CENTER);
  text("Thanks For Playing", width/2, height/3);
}



void drawButton() {
  pushStyle();
  button2.render();
   if (button2.isHovering()) {
    fill(#ED51EB); 
  } else {
    fill(150); 
  }
  textAlign(CENTER, CENTER);
  textSize(20);
  fill(0);
  text(">>>", button2.x, button2.y);
  popStyle();
}

void drawOfficer(float x, float y) {
  if (frameCount % officerDelay == 0) {
    officerCurrent = (officerCurrent + 1) % officer.length;
  }
  imageMode(CENTER);
  image(officer[officerCurrent], x, y);
}

void drawTeacher(float x, float y) {
  if (frameCount % teacherDelay == 0) {
    teacherCurrent = (teacherCurrent + 1) % teacher.length;
  }
  imageMode(CENTER);
  image(teacher[teacherCurrent], x, y);
}

void drawJessica(float x, float y) {
  if (frameCount % jessicaDelay == 0) {
    jessicaCurrent = (jessicaCurrent + 1) % jessicaMad.length;
  }
  imageMode(CENTER);
  image(jessicaMad[jessicaCurrent], x, y);
}
//(way to shorthand textboxes) https://chatgpt.com/share/69e6de8a-bf5c-83ea-be67-366474f3fdf6
//I dont usually shorthand my code but i had to a lot for this one
//https://www.bing.com/images/search?view=detailV2&ccid=J2ZmSyXu&id=36627835213C5E1B859F203981EBBE784016ACD5&thid=OIP.J2ZmSyXuv_bAqKlxCK9qHQHaHp&mediaurl=https%3A%2F%2Fwww.shutterstock.com%2Fimage-vector%2Fpoliceman-character-pixel-art-80s-600w-795518065.jpg&cdnurl=https%3A%2F%2Fth.bing.com%2Fth%2Fid%2FR.2766664b25eebff6c0a8a97108af6a1d%3Frik%3D1awWQHi%252b64E5IA%26pid%3DImgRaw%26r%3D0&exph=620&expw=600&q=cop+simple+pixel+art&form=IRPRST&ck=7EC8F7B544D53292134CB0569487398A&selectedindex=4&itb=0&ajaxhist=0&ajaxserp=0&pivotparams=insightsToken%3Dccid_J1YQicVZ*cp_9AC817C12EF5980664C8AA8C096C33BC*mid_66513EF5FAC26E681E908FFE099D3E73C45CF57F*thid_OIP.J1YQicVZ7m2nqu7Rrw2lPgHaJi&vt=0&sim=11&iss=VSI

class TextBox {

  int x;
  int y;
  int w;
  int h;
  int t;

  String text;

  color backgroundColor;
  color textColor;
  color borderColor;
 
///////////////////////// constructor
  TextBox(int startX, int startY, int startW, int startH, String startText, int startingTextSize) {

    x = startX;
    y = startY;
    w = startW;
    h = startH;
    t = startingTextSize;

    text = startText;

    backgroundColor = color(60);
    textColor = color(255);
    borderColor = color(255);
  }

 
  void render() {

    fill(backgroundColor);
    stroke(borderColor);
    rectMode(CENTER);
    rect(x, y, w, h);

    fill(textColor);
    textAlign(CENTER, CENTER);
    textSize(t);

    text(text, x + 10, y);
  }


  void setText(String newText) {
    text = newText;
  }
}

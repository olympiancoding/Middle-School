class Button{
  float x;
  float y;
  int w;
  int l;
  color c;

 Button(int startingX, int startingY, int startingW, int startingL, color startingC){
    x = startingX;
    y = startingY;
    w = startingW;
    l = startingL;
    c = startingC;
 }
 
 void render(){
  rectMode(CENTER);

  // 👇 HOVER COLOR LOGIC (fixed)
  if (isHovering()) {
    fill(255, 105, 180); // pink
  } else {
    fill(c); // default color
  }

  rect(x, y, w, l); 
 }
 
 boolean isHovering() {
  return mouseX > x - w/2 && mouseX < x + w/2 &&
         mouseY > y - l/2 && mouseY < y + l/2;
 }

 boolean isInButton() {
  float left = x - w/2;
  float right = x + w/2;
  float top = y - l/2;
  float bottom = y + l/2;
  
   if(mouseX >= left && mouseX <= right &&
     mouseY >= top && mouseY <= bottom){
       return true;
  }
  else{
    return false;
  }
 }

 boolean isPressed(){
  if(isInButton() == true && mousePressed == true){
    return true;
  }
  else{
    return false;
  }
 }
}
